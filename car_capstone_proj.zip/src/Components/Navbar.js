import React from 'react'
import { useEffect } from 'react';
import { Link } from 'react-router-dom'
import { withRouter } from 'react-router-dom';

function Navbar(props) {
  
  let logout=()=>{
    localStorage.clear();
    props.history.push("/")

  }
// let isLogin;
//   useEffect(()=>{`  `
// const isLogin = localStorage.getItem("roles")
//   },[])



  return (
    
    <div>
      <nav className="navbar navbar-expand-lg navbar-light " >
          <div className="container-fluid">
             <img className='img' src='data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBxQTEhQUExQWEhETExEWFhEXExgWGhcTGBYXFxcYGBYZIioiGRsnHBgXIzQkJystMDAwGCE2OzYuOjcvMC0BCwsLDw4PGxERHC8lIictLy8xMTEvLy8xLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vL//AABEIAOEA4QMBIgACEQEDEQH/xAAbAAEAAwEBAQEAAAAAAAAAAAAABAUGAwcBAv/EAEkQAAICAQEEBAgJCQcEAwAAAAABAgMRBAUSITEGQVFhEyIycYGRsdIHQlJTVJOhwdEUFiNDYnKCkrIXRIOiwuHwFTNzlCQ0Y//EABkBAQADAQEAAAAAAAAAAAAAAAABAgMEBf/EADERAAIBAgMFBgUFAQAAAAAAAAABAgMREiExBBNBUXEyUmGRofAUQoGxwQUi0eHxI//aAAwDAQACEQMRAD8AwgANzAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA/VcHJ4inJ9iTb9SJ1WxNTLydPc/wDBn+BVyS1f2JSbK8FzDoprHy01vpjj2s6robrvo0/XD3iu9p95eaJwy5FCC/fQvXfRp/zV+8fiXRHWrnprPQk/YxvqfeXmhhlyKMFlb0f1UfK016/wZv2IhX0Th5cJQfZKLj7SylF6NeaIszkACxAAAAAAAAAAAAAAAAAAAAAAB9SzwXFvqO89FalvOqxR+U65JevBDaWpJHAO+i0k7rI11rM5vC+9vsS5htJXYWZ22RsuzUWKupZfOUn5MY9sn93WdtuaWmmXgqpytnHhZa8KO91xhFdS622zV7XnHZ+lVNT/AE92U7Ovl48+7GcLsz5zAnPRqSqvHpHh4+L/AAaTioftevHw8DR7P6aammChBUqMVhLwKj/Q0ibD4RtUviUP+CfvmPBL2Wi3dwRCqzXE20fhL1S/VUfyz946L4UNT8zR6p+8YUEfB0O4hvZ8zef2pan5mj1We8c5fCdqfmqPVP3jDgfB0O4hvZ8zZy+ErVdVdC/gn75Gv6f6qaaapw+rwTf2Sk0ZUErZKC+Re/qN7PmTtA6Z241GYQm+NlaUfBtvnuYw49yxhcuxyNv7Bs00llqyqfkXR8mXXjueOOPVkqTcdDNdDU0z0d63ko5rzz3OtJ9Ti8Nf7EVpSpf9FmlqvDmuhMEp/tevAw4LDbmyp6a11y4rnCfVKHU/P1NFebxkpJSWjM2mnZgEinR2TWYVzmu2MJNetI4zg4vEk4vsaafqZN0LH5ABJAAAAAAAAAAPp8AB6PsLQVVVxdeJNpZtWG5enqXcdttb7psjXXKyU4SjwcVjKxl5ab9B5vpnPeSr3t+TSSi2m36D0DZWdNV/8m9OTeUpyXi9yb4yf/F3+LtGzunJTcsTb04vyPSpVcccKVlzMBPS2KSg4TU28KDi02+5dZ6R0T2CtPDenh3zXjP5MfkL731vzI4S6W6VPy5S71XL70iboOkelteI2pSfxZpw9W9hP0E7TWr1IWcGlx1/gpSp0oSviTZh+md856qbnGUYx8StSTWYR612pvL9JRntltEZx3ZxjOL+LJKS9TKfV9CdLZ5MZUt9dcuH8ssr1YNKH6hTjFRkrW+pSps0m20zysG7v+DiWf0eoTXZOtr7U37CJP4OdX8WdEv45r/Qda2yg/mMHRqLgY8Gsfwea3qjU/NavvSPx/Z9rvmov/Fr/Ev8TR768yN3PkzLA1X9nuv+aj9bX+J+18Het+RWvPavuyPiaPfXmRu58mZIGxh8G+s65UR/xJv2QJdXwaWfH1EEv2a5S9rRR7ZQXzosqM+Rgybse+yF9c6oynZCSahFNuS+MsLtWV6T0TR9AdNDy9+5/tS3V6oYf2l7ptFXUt2quNceyMUs+fHM56v6jTs1FX65I1hs0r5uxXdIdkQ1NW4/FkuMJ44xl39z5Nf7HlWo0NldjqlCXhE8bqTee9Y5pnqu0tu6el4stipLnBZlJeeMctekq/zw0rflyXe65fdxObZatenFqMG4m1aFObzkkzj0TrthQq7Kpww5NSe6uDecbud5P0FhtHR12wcbYpx48Xwce9S6jlqdVDU1Sjp9Qo2YypRfFdzi/GSfaeebSruhNwucnJfKk5Jrqab5oilQdepKV8Mr3tZ36lpVFSglbEvQ46mtRnKKkpRjKSUl1pPgzkAe2tDzgACSAAAAAAAAADvpNVKqW9B7ssNKWE2s88Z5PvJn/SNRZBXbkrFJZ3t5Sk15s5Kw3PQraMZVeBbxZXnC7YN5yvM3j1HLtU5Uo7yCT59DejFTlhk/9MPKLTaaw1zT4NPvR8PU9p7Gq1C/SR8bHCxcJL09a7nwMJtzo7bpvGfj1dVqXLukviv7O8rs+2Qq5aP3oxV2eUM9UNidJL9M0ovfqX6qTysfsvnH0cO43i2rLWUSlo7XVqIeM6motv8AZaknwfVJdfpR5Wd9Hq51TjZXJwnHlJexrrXcTX2WM3iirS9H1REKzjk9PehbfnfrV+vkn2eDr4P+U+rpnrfpD+rr90qdoarwts7N1QdknJxXLefGWO5vL9JHNdzT4wXkimOXM0K6a676S/q6vdC6ca/6S/q6vcM8CdxS7q8iMcuZovz51/0h/V1e4fH031/0l/V1e6Z4DcUu6vJDHLmX76aa76Q/q6vdD6Za36Q/q6/dKA+xxlZWVlZXLK61kbil3V5IY5cz1DYe0batP+U669tWJeDrcYJ7vNYUUnKUueOpfZk9vdMLtQ3Gtumn5MX40l+1JexcPOVG2Nq2aizfsfLhGC4RhH5MV1L2kEwpbJGMsc0r+i6fyaSqu2GOh9SPhL2bs23UT3Ko7z63yjFdsn1G+2N0UqoxKeLrflNeLF/sx+98fMaV9phR7Wb5EU6MqmmhiNDsTUWYlXXLHNTbUPSnJrPnRw12ssniNr3pVuUU3xku1OXWsrryembY2hGiqVkny4Rj1yl1JHlMpNtt822353zMtlrSrtylFWWn+l61NU7RTz4nwAHac4AAAAAAAAAAAAP3VY4yUotxlF5Uk8NM/AIJNjsnppjEdRHP/wCsF/VD8PUavQbUovWIWQnlcYZ447HB8fsPIz6cNX9Ppzd45fbyOiG1TjrmbbpL0Nxm3TLvlR99fu+rsMQWGl2zqK/IvsiuzfbXqeUQ9RdKcpTk8yk25PCWW+bwuB0UIVILDNp8nxM6koSd4qxzABuZAAAAAAAAAAv+jXRizUveea6E8OzHGT61BPn5+S7+RQFnHbt+7Gvw84VpKKUPF3YrhwUcZ4GVVVHG1NpPm/wXhhT/AHHpsK6NLUopwprXypJZfa2+MmZ/anTSmOVSnbL5TzGHrfF+r0lPPofdZBXVXV6hSWVLeknL0yXPztGauqlCTjJOMotpxfNNHBR2SjNtylifHh/Z01K9SKslZEjaW0rL579ssvqS4RiuyK6iIAemkoqyORtt3YABJAAAAAAAAAAAAAAAB9Tx3PtNFs7aulmtzVURz8/XHdb/AH1DD9K9RnAZ1KamrP0dmWjJx0N7Dofpr472mveO5xsS7muEl6WQdR8H+oX/AG7K7PPvQfsa+0ydVkovei3GS5Si2mvSi90XTLVV/rFauyyKl/mWJfaczpbTDsTv1Rqp0n2o26HPUdEtZDnRKS7YSjP7IvP2Fbds66Hl02w/eqnH2o2mj+EjH/d0/wDFCz/TJfeXWk+EPSPyvC1/vV5/obKOvtUe1Tv09snBSekrHk8njnwPzvrtXrPbqemGhn/eIL96Mo/1Ikx6S6D6Rp/5olfjprWk/f0G5XeR4RvrtXrP3Hjy4+bie7/nNoF/edP/ADxOF3TPQx/vMH+6pS/pRPx03pSfv6DcrvI8Zq2bdLyabZfu1Tl7ETqOi2sny01i/eSh/W0eiar4RdGvJdtv7tbX9biUmt+Ev5rT/wAVlmP8sV95ZV9plpTt19ojBSWsvIqNP0B1UvLddS757z9UU19pPXQeilb2o1OI927WvNmTeSo1/TTV2/rFUuyuO7/meZfaZ+62U3vTlKcvlSbk/Wyyp7TPtzUei/IcqS0jfqendG9TpfHp0u84wxOcnvYbfDnPi3w6ljgYPpPq426m2cMOGYpSXxt2Ki3616sEGjWThCcIScY27qnj4yWcLPZxfDrOBajsqp1JTve/t3+oqVcUVGwAB1mAAAAAAAAAAAAAADALDRbFvtjvQh4r5SclHPmy+JKXRjUfIj9ZD8T50pz4WK/Vqqvwa6t3HxfSUuEc8HVqRUk0r+Dfrc2koReFp+ZN2fsu29tVQct3m8pJeeT4Fi+ier6q0+5WQz7STQqfyGlXTsrjOy5tVpPelGTXjZ7Fgiwp0Caau1Ka4pqEE0+544FHWqNu18m12W9PG5OCKSv97ELQbHuuslXCH6SCblGTUGsNJ53u9lkuhur+bj9bD8S/uhCWo1LlJxhZs1Odm7l4fBzcVze6lw7jOf8ATND9Ml/6sykdonN5ZZL5W9V4Euko65/WxE2rsHUadKV1e7CTwpqUZRz2Nxbw/OT9N0M1c4qSqUVJJpTshF4fJuLeV6SdtSqvSaPwdU5aiOrlXZG1x3a4quSlwjny28Jrs8xy2lr9n6qx33vU13TUN+EPBSinGKj4rlxxwLKrVkrxWV3movhbhfLiVcIp2f3/ACcLuhOrjGU3CG7GMpP9NDkll8M8eRnDUaDYeg1MnVp7dQr3CcoeFhXuNxW9huCyuXP28jLpm1KcndS16NfllJJLT73JOg0Vl9kaqoudk3hRXtb5JLtZ9v0E4XeAe67d+MMRmpLfbSxvLhzeH2G02XfoqdL4OnWqjUXRXh7/AMmtnNRay6q8Y3En1ptvHmxXbN2Noo3UuO0FKStqcYfkli3mprEc54ZeEU+Izd00ukvXInBp/KMzrtJOmydVixZXJxksp4a71zP3boLI0wua/RWSnGMsrjKPCXDmif0y/wDvar/zS+4mbOtpv0sdNbdHTW02zsrsmvEnGflRk/itP7u8tvHgjPna/wBVqMObRm0idPY9yvdG45XrGYRafUpc+WMNcS5fRiql1zv1dKrko2JQ3pSnXzTguvPaSatou9bTvqTjOUKd3HlKlPdly5eLFN4KS2i+cM1zz1bSRKp8Je8rlb+aGq+bj9bD8SJtDYOopjv2V+J1yjKMkvPuvgVPDuL7og/0ly/VOi7wi+LjHBvq/wCMtN1acXJtO3hb8sRUJO2fn/RVX6ScIVzksRtUnB5TyovD4dXM51VuUlFc5NJedvCLfayzpdHLqUbot9kt5cH38H6iu2XFu+pLi/C18F3STf2Jl4zbg5Phf0uVcbSS6epy1FLhKUJLEotprOeK70cybtqWdRdjj+ln7WQi0HeKb5ESVm0AAXKgAAAAAAAAFlpNt21xUE4zgvJU4KW75skhdJLfk0/UopQYuhSbu4o0VWaVrkq3WylVCp43K3Nx4ccyeXlkUA1SS0KN31LOe3LW5N7uZ6f8nfi/qvXz7ysAIjCMeyrEtt6k2G07FRLT8JUykp4ksuE+2D+K/wAX2stYdMtQkkoafCSXHTx6vSZ0FZUactUFKS4miv6Z6qUJQXgqt+Li5V0xhLdfNKXVnuM6ATCnGHZVg5N6g6UWuE4zj5UJRkvPFpr7UcwWKknaGsldbO2eN+yTlLCwsvsXURgAlbJEvMma7XztVSnjFNUaoYWPEjyz2s/Gg11lE1ZVJwmuGVxyutNPg0RgRhVsNshd3uXz6WX/ACKfqERtd0gvtg624wg/KjCChvefHFlUDNUKSd1FFnUm+JP2fte2lOMGnCTy4SipRz24fJkmzpHe00tyvKxvQrUXjz9RTgl0abd3FBVJJWTAANSgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAB//2Q==' alt='logo'></img>
            <h1>CARS to buy </h1>
            <button className="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
              <span className="navbar-toggler-icon" />
            </button>
            <div className="collapse navbar-collapse" id="navbarSupportedContent">
              <ul className="navbar-nav me-auto mb-2 mb-lg-0">
                <li className="nav-item">
                  <Link className="nav-link active" aria-current="page" to="/">HOME</Link>
                </li>
                <li className="nav-item">
                  <Link className="nav-link" to="/adminLogin">LOGIN</Link>
                </li>
            
               
              </ul>
              <form className="d-flex">
                <input className="form-control me-1" type="search" placeholder="Search" aria-label="Search" />
                <button className="btn btn-outline-light" type="submit">Search</button>
              </form>

             
                  <Link className="nav-link" to="/logout" onClick={()=>{logout()}}>LOGOUT</Link>
                
            </div>
          </div>
        </nav>


    </div>
  )
}

export default withRouter (Navbar)