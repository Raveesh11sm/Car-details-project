import React, { useState } from "react";
import { withRouter } from "react-router-dom";
import { axios } from "axios";
import Admin from './Admin';

function Signup(props) {
  const [AdminDetails, setAdminDetails] = useState({
    username: "",
    password: "",
    roles: "",
  });

  const [passError, setPassError] = useState("");

  const [nameerror, setnameerror] = useState("");

  const expr = /^[a-zA-Z_]{3,15}$/;
  const validateName = (name) => {
    if (name && expr.test(name)) {
      setnameerror(true);
      setnameerror("");
      return true;
    } else {
      setnameerror(false);
      setnameerror("Please enter the valid name");
      return false;
    }
  };

  const isPassValid = (a) => {
    let imp = /^(?=.*[A-Za-z])(?=.*\d)(?=.*[@$!%*#?&])[A-Za-z\d@$!%*#?&]{8,}$/;
    if (imp.test(a)) {
      setPassError("");
      return true;
    } else {
      setPassError("password must contain alphanumeric value !!!");
      return false;
    }
  };

  let updateSignupData = (e) => {
    setAdminDetails({
      ...AdminDetails,
      [e.target.name]: e.target.value,
    });
  };
  let signupSubmit = (e) => {
    e.preventDefault();
  };

  let signup = async (e) => {
    let res = await axios.post("http://localhost:8089/admin/adminLogin");
    console.log(res);
    let passValid = isPassValid(AdminDetails.password);
    let nameValid = validateName(AdminDetails.username);

    if (res.data.error) {
      console.log(res.data.message);
    } else {
      console.log(res.data.message);
      alert("signedup  successfully");
      props.history.push("/admin/adminLogin");
      setAdminDetails({
        username: "",
        password: "",
        roles: "",
      });
    }
  };

  let goToLogin = (e) => {
    props.history.push("/admin/adminLogin");
  };
  return (
    <div>
      <h1>SIGNUP FORM</h1>
      <form className="container" onSubmit={signupSubmit}>
        <div className="mb-3">
          <label htmlFor="exampleInputPassword1" className="form-label">
            full name
          </label>
          <input
            value={AdminDetails.username}
            onChange={updateSignupData}
            name="username"
            type="text"
            className="form-control"
            id="exampleInputPassword1"
          />
          {validateName ? <span id="errmsg">{nameerror}</span> : null}
        </div>

        <div className="mb-3">
          <label htmlFor="exampleInputPassword1" className="form-label">
            Password
          </label>
          <input
            value={AdminDetails.password}
            onChange={updateSignupData}
            name="password"
            type="password"
            className="form-control"
            id="exampleInputPassword1"
          />
          {isPassValid ? <span id="errmsg">{passError}</span> : null}
        </div>
        <div className="mb-3">
          <label htmlFor="exampleInputPassword1" className="form-label">
            enter your role
          </label>
          {/* <input
            value={AdminDetails.adminRoles}
            onChange={updateSignupData}
            name="adminRoles"
            type="text"
            className="form-control"
          /> */}


          <select>
            <option>select</option>
            <option>Admin</option>
            <option>SUPERADMIN</option>

          </select>
        </div>
        <button
          onClick={(e) => {
            signup();
          }}
          type="submit"
          className="btn btn-success"
        >
          Submit
        </button>
      </form>
      <h5
        onClick={(e) => {
          goToLogin();
        }}
      >
        Already have an account login
      </h5>
    </div>
  );
}

export default withRouter(Signup);
