import React from 'react'

function Home() {
  return (
    <div>
<div id="carouselExampleCaptions" className="carousel slide" data-bs-ride="carousel">
          <div className="carousel-indicators">
            <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to={0} className="active" aria-current="true" aria-label="Slide 1" />
            <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to={1} aria-label="Slide 2" />
            <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to={2} aria-label="Slide 3" />
          </div>
          <div className="carousel-inner" id='carosal'>
            <div className="carousel-item active">
              {/* <img src="https://imgd.aeplcdn.com/1056x594/n/cw/ec/40027/safari-exterior-right-front-three-quarter-73.jpeg?q=75&wm=1.jpg." className="d-block w-100" alt="safari" /> */}
              <div className="carousel-caption d-none d-md-block">
                <h5>All Kinds Of You Dream Cars</h5>
              </div>
            </div>
            <div className="carousel-item">
              <img src="https://wallpapercave.com/wp/wp4455833.jpg" className="d-block w-100" alt="swift" />
              <div className="carousel-caption d-none d-md-block">
               
              </div>
            </div>
            <div className="carousel-item">
              {/* <img src="https://gumlet.assettype.com/evoindia%2Fimport%2F2019%2F04%2FINRC-4.jpg?auto=format%2Ccompress&fit=max&format=webp&w=480&dpr=2.6" className="d-block w-100" alt="SWIFT" /> */}
              <div className="carousel-caption d-none d-md-block">
              
              </div>
            </div>
          </div>
          <button className="carousel-control-prev" type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide="prev">
            <span className="carousel-control-prev-icon" aria-hidden="true" />
            <span className="visually-hidden">Previous</span>
          </button>
          <button className="carousel-control-next" type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide="next">
            <span className="carousel-control-next-icon" aria-hidden="true" />
            <span className="visually-hidden">Next</span>
          </button>
        </div>



        
    </div>
  )
}

export default Home