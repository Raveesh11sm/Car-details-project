import React, { useEffect, useState } from 'react'
import { Table } from 'react-bootstrap'
import AddCarDetails from './AddCarDetails';
import  axios  from 'axios';
import UpdateCarDetails from './UpdateCarDetails';

function Admin() {
    const [CarDetails, setCarDetails] = useState([])
    const [showAddModel, setshowAddModel] = useState(false)
    const [selectedProduct, setselectedProduct] = useState({})
    const [showEditModel, setshowEditModel] = useState(false)
    useEffect(() => {
      fetchProducts();
    }, []);
    let fetchProducts=async()=>{
    
      let jwtToken=localStorage.getItem("jwtToken");
      let token=`Bearer ${jwtToken}`
      
      
        let res = await axios.get("http://localhost:8089/admin/getInfo",
        {
          headers:{"Authorization":token}
        }
       );
       console.log(res);
        console.log(res.data.allCarsDetails);
        if(res.data.error){
          alert(res.data.message);
        }else{
          let fetchProducts=res.data.allCarsDetails;
          setCarDetails(fetchProducts);
        }
    
    }
    console.log(CarDetails);
  
    let hideAddModel=()=>{
         setshowAddModel(false)
    };
  
    //selected cars
    let updateProduct=(car)=>{
      setshowEditModel(true);
      setselectedProduct(car);
    }
    
    let hideEditModel =()=>{
      setshowEditModel(false);
    }
  
    let deleteProduct = async(id)=>{
       try{
        let jwtToken=localStorage.getItem("jwtToken");
        let token=`Bearer ${jwtToken}`
         let res =await axios.delete(`http://localhost:8080/carsforyou/${id}`,
         {
          headers:{"Authorization":token}
        });
         console.log(res.data.carDetails);
         if(res.data.error){
           alert(res.data.message);
         }else{
          alert(res.data.message);
          fetchProducts();
         }
       }catch(err){
         console.log(err);
       }
    }
    
    return (
      <div>
          <Table striped bordered hover>
    <thead>
      <tr>
        <th>IMAGE</th>
        <th>car id</th>
        <th>car Name</th>
        <th>car company</th>
        <th>fuel type</th>
        <th>power Steering</th>
        <th>Break System</th>
        <th>milage</th>
        <th>showroom price </th>
        <th>onroad price</th>
        <th>seating Capacity</th>
        <th>engine capacity</th>
        <th>gear Type</th>

        <th>
          <button className='btn btn-warning' onClick={()=>{setshowAddModel(true)}}>ADD</button>
        </th>
        
      </tr>
    </thead>
    <tbody>
    {CarDetails.map((car)=>{
      return (
        <tr key={car.id}>
        <td>
          <img width={"300px"} height= "250px" src={car.imageUrl} alt={car.name}></img>
        </td>
        <td>{car.id}</td>
        <td>{car.name}</td>
        <td>{car.company}</td>
        <td>{car.fuelType}</td>
        <td>{car.powerSteering}</td>
        <td>{car.breakSystem}</td>
        <td>{car.mileage}</td>
        <td>{car.showroomPrice}</td>
        <td>{car.onroadPrice}</td>
        <td>{car.seatingCapacity}</td>
        <td>{car.engineCapacity}</td>
        <td>{car.gearType}</td>

       
       
      
        <td>
        <button className='btn btn-primary m-2' onClick={()=>{updateProduct(car)}}>Update</button>
         <button className='btn btn-danger' onClick={()=>{deleteProduct(car.id)}}>Delete</button>
        </td>
      </tr>
    )
      
    })}
     
     
    </tbody>
  </Table>
  <AddCarDetails  showAddModel={showAddModel} hideAddModel={hideAddModel} fetchProducts={fetchProducts}/>
   <UpdateCarDetails selectedProduct={selectedProduct} showEditModel={showEditModel} hideEditModel={hideEditModel} fetchProducts={fetchProducts} />
      </div>
    )
}

export default Admin

